package com.example.resturantsystem;



public interface CategoryListener {
    public void onClickListener(String Category);
}
