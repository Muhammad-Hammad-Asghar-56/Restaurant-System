package com.example.resturantsystem;

public interface NumpadListener {
    public void onClickListener(String word);
}
