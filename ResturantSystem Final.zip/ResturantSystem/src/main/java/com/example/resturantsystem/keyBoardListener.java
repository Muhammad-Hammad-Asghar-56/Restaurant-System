package com.example.resturantsystem;

import javafx.scene.control.Dialog;

public interface keyBoardListener {
    public void onClickListener(String word);
}
